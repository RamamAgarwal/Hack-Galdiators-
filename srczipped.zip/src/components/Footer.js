import React from 'react';

const Footer = () => {
  return (
    <footer className="footer" role="contentinfo">
      <div className="p-4 text-center">
        <p>© {new Date().getFullYear()} GigID Verify - Blockchain-based Digital Identity Solution</p>
        <p>Built on Ethereum Base Layer 2</p>
        <p>
          Contact us at{' '}
          <a href="mailto:xyz@email.com" className="text-indigo-600 hover:underline">
            xyz@email.com
          </a>{' '}
          or call{' '}
          <a href="tel:9874563210" className="text-indigo-600 hover:underline">
            9874563210
          </a>
        </p>
      </div>
    </footer>
  );
};

export default Footer;