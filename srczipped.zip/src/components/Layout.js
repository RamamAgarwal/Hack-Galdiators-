import React, { useState, useEffect } from 'react';
import Header from './Header';
import Footer from './Footer';
import { connectWallet } from '../utils/blockchain';
import Link from 'next/link';
import { useRouter } from 'next/router';

const Layout = ({ children }) => {
  const [walletInfo, setWalletInfo] = useState({
    address: null,
    chainId: null,
    connected: false
  });

  const handleConnectWallet = async () => {
    const info = await connectWallet();
    setWalletInfo(info);
  };

  useEffect(() => {
    // Check if wallet is already connected
    const checkWalletConnection = async () => {
      try {
        if (window.ethereum) {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          if (accounts.length > 0) {
            handleConnectWallet();
          }
        }
      } catch (error) {
        console.error("Error checking wallet connection:", error);
      }
    };

    checkWalletConnection();

    // Listen for account changes
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', handleConnectWallet);
      window.ethereum.on('chainChanged', handleConnectWallet);
    }

    return () => {
      if (window.ethereum) {
        window.ethereum.removeListener('accountsChanged', handleConnectWallet);
        window.ethereum.removeListener('chainChanged', handleConnectWallet);
      }
    };
  }, []);

  return (
    <div>
      <Header 
        walletAddress={walletInfo.address} 
        connectWallet={handleConnectWallet} 
      />
      <main className="container">
        {children}
      </main>
      <Footer />
    </div>
  );
  const isActive = (path) => router.pathname === path;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <span className="text-xl font-bold text-indigo-600">ID Verify</span>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                <Link href="/">
                  <span className={`${isActive('/') 
                    ? 'border-indigo-500 text-gray-900' 
                    : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'} 
                    inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`}>
                    Home
                  </span>
                </Link>
                <Link href="/dashboard">
                  <span className={`${isActive('/dashboard') 
                    ? 'border-indigo-500 text-gray-900' 
                    : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'} 
                    inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`}>
                    Dashboard
                  </span>
                </Link>
                <Link href="/verify">
                  <span className={`${isActive('/verify') 
                    ? 'border-indigo-500 text-gray-900' 
                    : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'} 
                    inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`}>
                    Verify
                  </span>
                </Link>
                <Link href="/transactions">
                  <span className={`${isActive('/transactions') 
                    ? 'border-indigo-500 text-gray-900' 
                    : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'} 
                    inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`}>
                    Transactions
                  </span>
                </Link>
              </div>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:items-center">
              {/* User menu or wallet connection button would go here */}
              <button type="button" className="bg-indigo-600 px-4 py-2 rounded-md text-sm font-medium text-white hover:bg-indigo-700">
                Connect Wallet
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main content */}
      <main>{children}</main>
      
      {/* Footer */}
      <footer className="bg-white">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-500">
            &copy; {new Date().getFullYear()} ID Verify. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;