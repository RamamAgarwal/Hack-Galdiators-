import React, { useState, useEffect } from 'react';

const Notification = ({ message, type, duration = 5000 }) => {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
    }, duration);

    return () => clearTimeout(timer);
  }, [duration]);

  if (!visible) return null;

  const notificationStyle = {
    position: 'fixed',
    top: '20px',
    right: '20px',
    padding: '15px 20px',
    borderRadius: '5px',
    boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
    zIndex: 1000,
    backgroundColor: type === 'error' 
      ? 'var(--error-color)' 
      : type === 'success' 
        ? 'var(--success-color)' 
        : 'var(--primary-color)',
    color: 'white',
    transition: 'opacity 0.5s ease', // Optional: Add transition for fade-out effect
    opacity: visible ? 1 : 0 // Optional: Control opacity for fade-out effect
  };

  return (
    <div style={notificationStyle} role="alert">
      {message}
      <button 
        onClick={() => setVisible(false)}
        aria-label="Close notification"
        style={{
          background: 'transparent',
          border: 'none', // Changed to 'none' for a cleaner look
          color: 'white',
          marginLeft: '10px',
          cursor: 'pointer',
          padding: '0 5px'
        }}
      >
        ✕
      </button>
    </div>
  );
};

export default Notification;