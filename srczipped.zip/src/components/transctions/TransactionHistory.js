import React, { useState, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { getTransactions } from '../../utils/blockchain';

const TransactionHistory = ({ address }) => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTransactions = async () => {
      if (!address) return;

      try {
        setLoading(true);
        const txList = await getTransactions(address);
        setTransactions(txList);
      } catch (err) {
        console.error("Failed to fetch transactions:", err);
        setError("Failed to load transaction history. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [address]);

  // Optional: Use a flag to toggle demo data for development
  const useDemoData = false; // Set to true for demo data

  useEffect(() => {
    if (useDemoData && address) {
      const demoTransactions = [
        {
          hash: "0x3a8d9b1f5a92c95a3b151b214a9c1b43e38a11c3a4c3d1a3c95a9b1c3a9c1b43",
          from: address,
          to: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
          value: "0.01",
          timestamp: Date.now() - 1000 * 60 * 30, // 30 minutes ago
          status: "confirmed",
          type: "Identity Verification"
        },
        {
          hash: "0x4b9d8c2e6b93d6a4c5b7a8d9c2e6b93d6a4c5b7a8d9c2e6b93d6a4c5b7a8d9c2",
          from: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
          to: address,
          value: "0.05",
          timestamp: Date.now() - 1000 * 60 * 60 * 3, // 3 hours ago
          status: "confirmed",
          type: "Document Upload"
        },
        {
          hash: "0x5c8e7d3f4a82b5c9a6b7d3f4a82b5c9a6b7d3f4a82b5c9a6b7d3f4a82b5c9a6b",
          from: address,
          to: "0x82D6C7ad03dEEfB5aFceeAB3D969b0afEBb8520b",
          value: "0.002",
          timestamp: Date.now() - 1000 * 60 * 60 * 24, // 1 day ago
          status: "confirmed",
          type: "Verification Status Update"
        }
      ];

      setTransactions(demoTransactions);
      setLoading(false);
    }
  }, [address, useDemoData]);

  if (loading) {
    return (
      <div className="p-4 flex justify-center">
        <div className="animate-pulse flex space-x-4">
          <div className="flex-1 space-y-6 py-1">
            <div className="h-2 bg-gray-200 rounded"></div>
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-4">
                <div className="h-2 bg-gray-200 rounded col-span-2"></div>
                <div className="h-2 bg-gray-200 rounded col-span-1"></div>
              </div>
              <div className="h-2 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 p-4 rounded-md">
        <p className="text-red-500">{error}</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="border-b border-gray-200 px-6 py-4">
        <h3 className="text-lg font-medium text-gray-900">Transaction History</h3>
      </div>

      <div className="divide-y divide-gray-200">
        {transactions.length > 0 ? (
          transactions.map((tx) => (
            <div key={tx.hash} className="px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-indigo-600 truncate">
                  {tx.type}
                </p>
                <div className="mt-2 flex">
                  <p className="text-xs text-gray-500 truncate">
                    {tx.from.substring(0, 8)}...{tx.from.substring(tx.from.length - 6)} →{' '}
                    {tx.to.substring(0, 8)}...{tx.to.substring(tx.to.length - 6)}
                  </p>
                </div>
                <p className="mt-1 text-xs text-gray-500">
                  {formatDistanceToNow(new Date(tx.timestamp), { addSuffix: true })} ago
                </p>
              </div>

              <div className="mt-4 sm:mt-0 sm:ml-6 flex flex-col items-end">
                <p className="text-sm font-medium text-gray-900">
                  {tx.value} ETH
                </p>
                <div className="mt-1 flex items-center">
                  {tx.status === 'confirmed' ? (
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      Confirmed
                    </span>
                  ) : tx.status === 'pending' ? (
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                      Pending
                    </span>
                  ) : (
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                      Failed
                    </span>
                  )}
                </div>
              </div>

              <div className="mt-4 sm:mt-0 sm:ml-4">
                <a 
                  href={`https://sepolia.etherscan.io/tx/${tx.hash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`View transaction ${tx.hash}`}
                  className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
                >
                  View
                </a>
              </div>
            </div>
          ))
        ) : (
          <div className="px-6 py-4 text-center">
            <p className="text-gray-500">No transactions found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TransactionHistory;