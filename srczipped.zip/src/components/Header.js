import React from 'react';
import Link from 'next/link';

const Header = ({ walletAddress, connectWallet }) => {
  return (
    <nav className="navbar" role="navigation" aria-label="Main Navigation">
      <div className="navbar-content flex justify-between items-center p-4">
        <div className="navbar-logo">
          <Link href="/" className="text-lg font-bold">
            GigID Verify
          </Link>
        </div>
        <ul className="navbar-links flex space-x-4">
          <li>
            <Link href="/" className="hover:underline">Home</Link>
          </li>
          <li>
            <Link href="/dashboard" className="hover:underline">Dashboard</Link>
          </li>
          <li>
            <Link href="/verify" className="hover:underline">Verify Identity</Link>
          </li>
          <li>
            <Link href="/transactions" className="hover:underline">View Transactions</Link>
          </li>
          <li>
            {walletAddress ? (
              <span className="text-sm">
                {walletAddress.slice(0, 6)}...{walletAddress.slice(-4)}
              </span>
            ) : (
              <button 
                type="button" 
                onClick={connectWallet} 
                className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                aria-label="Connect Wallet"
              >
                Connect Wallet
              </button>
            )}
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Header;