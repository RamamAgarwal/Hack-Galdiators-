import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import TransactionHistory from '../components/transctions/TransactionHistory';
import Layout from '../components/Layout';

export default function TransactionsPage() {
  const [address, setAddress] = useState(null);
  const router = useRouter();
  
  // Check if user is connected
  useEffect(() => {
    const checkConnection = async () => {
      try {
        // Get wallet address from localStorage
        const userAddress = localStorage.getItem('userAddress');
        
        if (!userAddress) {
          // Redirect to home if not connected
          router.push('/');
          return;
        }
        
        setAddress(userAddress);
      } catch (error) {
        console.error("Error checking wallet connection:", error);
        // Optionally, handle the error (e.g., show a notification)
      }
    };
    
    checkConnection();
  }, [router]);

  return (
    <Layout>
      <Head>
        <title>Transaction History | Identity Verification DApp</title>
        <meta name="description" content="View your transaction history" />
      </Head>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Transaction History</h1>
          <p className="mt-2 text-sm text-gray-500">
            View all transactions related to your identity verification process
          </p>
        </div>
        
        {address ? (
          <div className="space-y-8">
            {/* Wallet Information */}
            <div className="bg-white rounded-lg shadow overflow-hidden p-6">
              <h2 className="text-lg font-medium text-gray-900 mb-2">Connected Wallet</h2>
              <p className="text-sm text-gray-500 break-all">
                {address}
              </p>
              <div className="mt-4">
                <a
                  href={`https://sepolia.etherscan.io/address/${address}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
                >
                  View on Etherscan
                </a>
              </div>
            </div>
            
            {/* Transaction History Component */}
            <TransactionHistory address={address} />
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <p className="text-gray-500">Loading...</p>
          </div>
        )}
      </div>
    </Layout>
  );
}