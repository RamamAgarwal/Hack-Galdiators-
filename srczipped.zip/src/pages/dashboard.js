import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { getVerificationStatus } from '../utils/blockchain';
import LoadingSpinner from '../components/LoadingSpinner';
import Notification from '../components/Notification';

export default function Dashboard() {
  const router = useRouter();
  const [walletAddress, setWalletAddress] = useState('');
  const [verificationStatus, setVerificationStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const checkWalletAndStatus = async () => {
      try {
        if (window.ethereum) {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          if (accounts.length > 0) {
            setWalletAddress(accounts[0]);
            
            // Get verification status
            const result = await getVerificationStatus(accounts[0]);
            if (result.success) {
              setVerificationStatus(result.status);
            } else {
              setError(result.error);
            }
          } else {
            setError('Please connect your wallet to view your dashboard');
          }
        } else {
          setError('Ethereum wallet not detected. Please install MetaMask');
        }
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    checkWalletAndStatus();
  }, []);

  const getStatusText = (status) => {
    switch (status) {
      case 0:
        return { text: 'Not Submitted', color: 'gray' };
      case 1:
        return { text: 'Pending Verification', color: 'orange' };
      case 2:
        return { text: 'Verified', color: 'green' };
      case 3:
        return { text: 'Rejected', color: 'red' };
      default:
        return { text: 'Unknown Status', color: 'gray' };
    }
  };

  const handleVerifyNow = () => {
    router.push('/verify');
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <Head>
        <title>Dashboard - GigID Verify</title>
        <meta name="description" content="View your identity verification status" />
      </Head>

      {error && <Notification message={error} type="error" />}

      <div className="card">
        <h1>Your Dashboard</h1>
        
        {walletAddress ? (
          <>
            <div style={{ marginTop: '30px' }}>
              <p><strong>Wallet Address:</strong> {walletAddress}</p>
            </div>

            <div className="card" style={{ marginTop: '30px' }}>
              <h2>Verification Status</h2>
              
              {verificationStatus !== null ? (
                <div style={{ 
                  marginTop: '30px', 
                  padding: '30px', 
                  backgroundColor: getStatusText(verificationStatus).color === 'green' ? '#e6ffe6' : 
                                    getStatusText(verificationStatus).color === 'orange' ? '#fff8e6' : 
                                    getStatusText(verificationStatus).color === 'red' ? '#ffe6e6' : 
                                    '#f5f5f5',
                  borderRadius: '8px',
                  border: `1px solid ${getStatusText(verificationStatus).color}`
                }}>
                  <h3 style={{ color: getStatusText(verificationStatus).color }}>
                    {getStatusText(verificationStatus).text}
                  </h3>
                  <p style={{ marginTop: '10px' }}>
                    {verificationStatus === 0 && 'You have not submitted your identity for verification yet.'}
                    {verificationStatus === 1 && 'Your identity verification request is being processed. This typically takes 24-48 hours.'}
                    {verificationStatus === 2 && 'Congratulations! Your identity has been verified. You can now use it across supported gig platforms.'}
                    {verificationStatus === 3 && 'Your verification was rejected. Please check your documents and try again.'}
                  </p>
                  
                  {(verificationStatus === 0 || verificationStatus === 3) && (
                    <button 
                      onClick={handleVerifyNow} 
                      style={{ marginTop: '18px' }}
                      className="btn-primary"
                    >
                      {verificationStatus === 0 ? 'Verify Now' : 'Try Again'}
                    </button>
                  )}
                </div>
              ) : (
                <p>No verification data found. Please submit your identity for verification.</p>
              )}
            </div>

            {verificationStatus === 2 && (
              <div className="card" style={{ marginTop: '30px' }}>
                <h2>Your Verification Certificate</h2>
                <div style={{ marginTop: '20px', padding: '20px', border: '1px dashed #ccc', borderRadius: '5px' }}>
                  <p>Your digital identity verification certificate:</p>
                  <div style={{ 
                    marginTop: '15px', 
                    padding: '20px', 
                    backgroundColor: '#f9f9f9', 
                    borderRadius: '5px',
                    fontFamily: 'monospace'
                  }}>
                    DID:ETH:{walletAddress}
                  </div>
                  <button 
                    className="btn-secondary" 
                    style={{ marginTop: '15px' }}
                    onClick={() => {
                      navigator.clipboard.writeText(`DID:ETH:${walletAddress}`);
                      alert('Certificate ID copied to clipboard!');
                    }}
                  >
                    Copy Certificate ID
                  </button>
                </div>
              </div>
            )}
          </>
        ) : (
          <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <p>Please connect your wallet to view your dashboard</p>
            <button 
              onClick={() => window.ethereum.request({ method: 'eth_requestAccounts' })}
              className="btn-primary"
              style={{ marginTop: '20px' }}
            >
              Connect Wallet
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
export default function Dashboard() {
    const router = useRouter();
    const [transactions] = useState([
      { id: '1', type: 'Verification', status: 'Complete', date: '2025-03-28' },
      { id: '2', type: 'Document Upload', status: 'Pending', date: '2025-03-29' },
      { id: '3', type: 'Identity Check', status: 'Processing', date: '2025-03-30' },
      { id: '4', type: 'KYC Submission', status: 'Complete', date: '2025-03-31' },
    ]);
  
    const handleShowTransaction = (id) => {
      router.push(`/transaction/${id}`);
    };
  
    return (
      <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-semibold text-gray-900 mb-6">Your Dashboard</h1>
          
          <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-8">
            <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
              <h2 className="text-lg leading-6 font-medium text-gray-900">
                Transaction History
              </h2>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Transaction ID
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {transactions.map((transaction) => (
                    <tr key={transaction.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        #{transaction.id}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {transaction.type}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          transaction.status === 'Complete' ? 'bg-green-100 text-green-800' : 
                          transaction.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' : 
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {transaction.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {transaction.date}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => handleShowTransaction(transaction.id)}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          View Transaction
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  }