import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { submitVerification } from '../utils/blockchain';
import { uploadToIPFS, uploadJSONToIPFS } from '../utils/ipfs';
import LoadingSpinner from '../components/LoadingSpinner';
import Notification from '../components/Notification';

export default function Verify() {
  const router = useRouter();
  const [walletAddress, setWalletAddress] = useState('');
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState({ message: '', type: '' });
  
  // Form data
  const [formData, setFormData] = useState({
    fullName: '',
    dateOfBirth: '',
    country: '',
    idType: 'passport',
    idNumber: '',
    idFrontFile: null,
    idBackFile: null,
    selfieFile: null,
  });

  // Preview states
  const [idFrontPreview, setIdFrontPreview] = useState('');
  const [idBackPreview, setIdBackPreview] = useState('');
  const [selfiePreview, setSelfiePreview] = useState('');

  useEffect(() => {
    const checkWallet = async () => {
      try {
        if (window.ethereum) {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          if (accounts.length > 0) {
            setWalletAddress(accounts[0]);
          }
        }
      } catch (error) {
        console.error("Error checking wallet:", error);
      }
    };

    checkWallet();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    if (files && files[0]) {
      setFormData(prev => ({ ...prev, [name]: files[0] }));
      
      // Generate preview
      const reader = new FileReader();
      reader.onload = (event) => {
        if (name === 'idFrontFile') setIdFrontPreview(event.target.result);
        if (name === 'idBackFile') setIdBackPreview(event.target.result);
        if (name === 'selfieFile') setSelfiePreview(event.target.result);
      };
      reader.readAsDataURL(files[0]);
    }
  };

  const nextStep = () => {
    setStep(prevStep => prevStep + 1);
  };

  const prevStep = () => {
    setStep(prevStep => prevStep - 1);
  };

  const validateStep1 = () => {
    if (!formData.fullName || !formData.dateOfBirth || !formData.country) {
      setNotification({ 
        message: 'Please fill in all required fields', 
        type: 'error' 
      });
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    if (!formData.idType || !formData.idNumber) {
      setNotification({ 
        message: 'Please fill in all required fields', 
        type: 'error' 
      });
      return false;
    }
    return true;
  };

  const validateStep3 = () => {
    if (!formData.idFrontFile || !formData.selfieFile) {
      setNotification({ 
        message: 'Please upload the required documents', 
        type: 'error' 
      });
      return false;
    }
    
    if (formData.idType !== 'passport' && !formData.idBackFile) {
      setNotification({ 
        message: 'Please upload the back side of your ID', 
        type: 'error' 
      });
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Final validation
    if (!validateStep3()) return;

    try {
      setLoading(true);
      
      // 1. Upload files to IPFS
      const idFrontResult = await uploadToIPFS(formData.idFrontFile);
      if (!idFrontResult.success) throw new Error('Failed to upload ID front');
      
      let idBackResult = { success: true, fileHash: '' };
      if (formData.idBackFile) {
        idBackResult = await uploadToIPFS(formData.idBackFile);
        if (!idBackResult.success) throw new Error('Failed to upload ID back');
      }
      
      const selfieResult = await uploadToIPFS(formData.selfieFile);
      if (!selfieResult.success) throw new Error('Failed to upload selfie');
      
      // 2. Create metadata
      const metadata = {
        fullName: formData.fullName,
        dateOfBirth: formData.dateOfBirth,
        country: formData.country,
        idType: formData.idType,
        idNumber: formData.idNumber,
        idFrontHash: idFrontResult.fileHash,
        idBackHash: idBackResult.fileHash || '',
        selfieHash: selfieResult.fileHash,
        walletAddress,
        timestamp: new Date().toISOString()
      };
      
      // 3. Upload metadata to IPFS
      const metadataResult = await uploadJSONToIPFS(metadata);
      if (!metadataResult.success) throw new Error('Failed to upload metadata');
      
      // 4. Submit hash to blockchain
      const submissionResult = await submitVerification(metadataResult.jsonHash);
      if (!submissionResult.success) throw new Error(submissionResult.error);
      
      // 5. Success!
      setNotification({
        message: 'Verification submitted successfully!',
        type: 'success'
      });
      
      // Redirect to dashboard after 2 seconds
      setTimeout(() => {
        router.push('/dashboard');
      }, 2000);
      
    } catch (error) {
      setNotification({
        message: 'Error: ${error.message}',
        type: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="card">
            <h2>Personal Information</h2>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                placeholder="Enter your full name as it appears on your ID"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Date of Birth</label>
              <input
                type="date"
                name="dateOfBirth"
                value={formData.dateOfBirth}
                onChange={handleChange}
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Country of Residence</label>
              <input
                type="text"
                name="country"
                value={formData.country}
                onChange={handleChange}
                placeholder="Enter your country of residence"
              />
            </div>
            
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '20px' }}>
              <button 
                className="btn-primary" 
                onClick={() => {
                  if (validateStep1()) nextStep();
                }}
              >
                Next
              </button>
            </div>
          </div>
        );
        
      case 2:
        return (
          <div className="card">
            <h2>Identity Document Information</h2>
            
            <div className="form-group">
              <label className="form-label">ID Type</label>
              <select
                name="idType"
                value={formData.idType}
                onChange={handleChange}
              >
                <option value="passport">Passport</option>
                <option value="nationalId">National ID Card</option>
                <option value="drivingLicense">Driving License</option>
              </select>
            </div>
            
            <div className="form-group">
              <label className="form-label">ID Number</label>
              <input
                type="text"
                name="idNumber"
                value={formData.idNumber}
                onChange={handleChange}
                placeholder="Enter your ID number"
              />
            </div>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '20px' }}>
              <button className="btn-secondary" onClick={prevStep}>
                Back
              </button>
              <button 
                className="btn-primary" 
                onClick={() => {
                  if (validateStep2()) nextStep();
                }}
              >
                Next
              </button>
            </div>
          </div>
        );
        
      case 3:
        return (
          <div className="card">
            <h2>Upload Documents</h2>
            
            <div className="form-group">
              <label className="form-label">Front side of ID</label>
              <input
                type="file"
                name="idFrontFile"
                onChange={handleFileChange}
                accept="image/*"
              />
              {idFrontPreview && (
                <div style={{ marginTop: '10px' }}>
                  <img 
                    src={idFrontPreview} 
                    alt="ID Front Preview" 
                    style={{ maxWidth: '100%', maxHeight: '200px', borderRadius: '5px' }} 
                  />
                </div>
              )}
            </div>
            
            {formData.idType !== 'passport' && (
              <div className="form-group">
                <label className="form-label">Back side of ID</label>
                <input
                  type="file"
                  name="idBackFile"
                  onChange={handleFileChange}
                  accept="image/*"
                />
                {idBackPreview && (
                  <div style={{ marginTop: '10px' }}>
                    <img 
                      src={idBackPreview} 
                      alt="ID Back Preview" 
                      style={{ maxWidth: '100%', maxHeight: '200px', borderRadius: '5px' }} 
                    />
                  </div>
                )}
              </div>
            )}
            
            <div className="form-group">
              <label className="form-label">Selfie with ID</label>
              <input
                type="file"
                name="selfieFile"
                onChange={handleFileChange}
                accept="image/*"
              />
              {selfiePreview && (
                <div style={{ marginTop: '10px' }}>
                  <img 
                    src={selfiePreview} 
                    alt="Selfie Preview" 
                    style={{ maxWidth: '100%', maxHeight: '200px', borderRadius: '5px' }} 
                  />
                </div>
              )}
            </div>
            
            <div className="form-group">
              <div style={{ padding: '15px', backgroundColor: '#f9f9f9', borderRadius: '5px', marginBottom: '20px' }}>
                <p><strong>Note:</strong> Please ensure that:</p>
                <ul style={{ marginLeft: '20px', marginTop: '10px' }}>
                  <li>Documents are clear and readable</li>
                  <li>Your selfie shows your face clearly alongside your ID</li>
                  <li>All information matches your submitted details</li>
                </ul>
              </div>
            </div>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '20px' }}>
              <button className="btn-secondary" onClick={prevStep}>
                Back
              </button>
              <button 
                className="btn-primary" 
                onClick={handleSubmit}
                disabled={loading}
              >
                {loading ? 'Submitting...' : 'Submit Verification'}
              </button>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };

  if (!walletAddress) {
    return (
      <div className="card">
        <h1>Connect Wallet</h1>
        <p>Please connect your wallet to proceed with identity verification</p>
        <button 
          onClick={() => window.ethereum.request({ method: 'eth_requestAccounts' })}
          className="btn-primary"
          style={{ marginTop: '20px' }}
        >
          Connect Wallet
        </button>
      </div>
    );
  }

  return (
    <div>
      <Head>
        <title>Verify Identity - GigID Verify</title>
        <meta name="description" content="Submit your identity for blockchain verification" />
      </Head>

      {notification.message && (
        <Notification 
          message={notification.message} 
          type={notification.type} 
        />
      )}

      {loading && <LoadingSpinner />}

      <div>
        <h1>Identity Verification</h1>
        
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          marginBottom: '30px',
          marginTop: '20px'
        }}>
          {[1, 2, 3].map((stepNumber) => (
            <div 
              key={stepNumber}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                width: '33%'
              }}
            >
              <div 
                style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: '50%',
                  backgroundColor: step >= stepNumber ? 'var(--primary-color)' : '#e0e0e0',
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  color: 'white',
                  fontWeight: 'bold',
                  marginBottom: '10px'
                }}
              >
                {stepNumber}
              </div>
              <div style={{ textAlign: 'center' }}>
                {stepNumber === 1 && 'Personal Info'}
                {stepNumber === 2 && 'ID Details'}
                {stepNumber === 3 && 'Upload Documents'}
              </div>
            </div>
          ))}
        </div>
        
        {renderStep()}
      </div>
    </div>
  );
}