import '../styles/globals.css';
import Layout from '../components/Layout';
import { useEffect } from 'react';

function MyApp({ Component, pageProps }) {
  useEffect(() => {
    // Handle client-side blockchain interactions
    const handleEthereum = () => {
      if (window.ethereum) {
        console.log('Ethereum provider detected');
      } else {
        console.log('Please install MetaMask or another Ethereum wallet');
      }
    };

    if (window.ethereum) {
      handleEthereum();
    } else {
      window.addEventListener('ethereum#initialized', handleEthereum, {
        once: true,
      });
      
      // If the ethereum#initialized event doesn't fire within 3 seconds,
      // the user doesn't have MetaMask/Ethereum wallet
      setTimeout(handleEthereum, 3000);
    }
  }, []);

  return (
    <Layout>
      <Component {...pageProps} />
    </Layout>
  );
}

export default MyApp;