import React from 'react';
import Head from 'next/head';
import Link from 'next/link';

export default function Home() {
  return (
    <div>
      <Head>
        <title>GigID Verify - Blockchain Identity Verification for Gig Workers</title>
        <meta name="description" content="Secure, verifiable, and decentralized identity verification for gig economy workers" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <section className="card">
        <h1 className="text-4xl mb-4">Blockchain Identity Verification</h1>
        <p className="text-lg mb-8">
          Secure your identity with blockchain technology and work confidently in the gig economy.
        </p>

        <div className="flex gap-5 mt-8">
          <Link href="/verify">
            <button className="btn-primary px-6 py-3 text-lg">
              Verify Your Identity
            </button>
          </Link>
          <Link href="/dashboard">
            <button className="btn-secondary px-6 py-3 text-lg">
              Check Verification Status
            </button>
          </Link>
        </div>
      </section>

      <section className="card">
        <h2 className="text-2xl">Benefits of Blockchain Identity Verification</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-5">
          <div className="card">
            <h3 className="text-xl">Secure & Tamperproof</h3>
            <p>Your identity is secured on an immutable blockchain, eliminating data mismatches and fraud.</p>
          </div>
          <div className="card">
            <h3 className="text-xl">Portable Across Platforms</h3>
            <p>Use your verified identity across multiple gig platforms without repeated verification processes.</p>
          </div>
          <div className="card">
            <h3 className="text-xl">Build a Reputation</h3>
            <p>Develop a verifiable work history that can help you access financial services and better opportunities.</p>
          </div>
        </div>
      </section>

      <section className="card">
        <h2 className="text-2xl">How It Works</h2>
        <ol className="list-decimal ml-5 mt-4">
          <li className="mb-4">Connect your wallet using MetaMask or WalletConnect</li>
          <li className="mb-4">Upload your identity documents securely</li>
          <li className="mb-4">Our system verifies your documents on the blockchain</li>
          <li className="mb-4">Once verified, your digital identity is ready to use across platforms</li>
        </ol>
      </section>
    </div>
  );
}