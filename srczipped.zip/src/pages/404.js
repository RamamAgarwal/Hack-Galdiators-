import React from 'react';
import Link from 'next/link';
import Head from 'next/head';

export default function Custom404() {
  return (
    <div style={{ textAlign: 'center', padding: '50px 20px' }}>
      <Head>
        <title>Page Not Found - GigID Verify</title>
      </Head>
      
      <h1 style={{ fontSize: '2rem', marginBottom: '20px' }}>404 - Page Not Found</h1>
      <p style={{ marginBottom: '30px' }}>The page you're looking for doesn't exist or has been moved.</p>
      
      <Link href="/">
        <button className="btn-primary">
          Return to Home
        </button>
      </Link>
    </div>
  );
}