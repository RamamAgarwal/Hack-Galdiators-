// pages/transaction/[id].js
import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function TransactionDetail() {
  const router = useRouter();
  const { id } = router.query;
  const [transaction, setTransaction] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    
    // Mock fetch transaction data
    // In a real app, you would fetch this from your API
    setTimeout(() => {
      setTransaction({
        id: id,
        hash: `0x${Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('')}`,
        from: `0x${Array(40).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('')}`,
        to: `0x${Array(40).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('')}`,
        amount: (Math.random() * 10).toFixed(5),
        status: Math.random() > 0.2 ? 'Confirmed' : 'Pending',
        timestamp: new Date().toISOString(),
        gas: Math.floor(Math.random() * 100000),
        gasPrice: (Math.random() * 100).toFixed(2),
        blockNumber: Math.floor(Math.random() * 1000000),
      });
      setLoading(false);
    }, 800);
  }, [id]);

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading transaction details...</div>;
  if (!transaction) return <div className="min-h-screen flex items-center justify-center">Transaction not found</div>;

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto bg-white rounded-lg shadow overflow-hidden">
        <div className="bg-blue-600 px-4 py-5 border-b border-gray-200 sm:px-6">
          <h1 className="text-lg leading-6 font-medium text-white">
            Transaction Details
          </h1>
        </div>
        
        <div className="px-4 py-5 sm:p-6">
          <div className="grid grid-cols-1 gap-4">
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Transaction Hash</span>
              <span className="font-mono text-sm break-all">{transaction.hash}</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Status</span>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                transaction.status === 'Confirmed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
              }`}>
                {transaction.status}
              </span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Block</span>
              <span>{transaction.blockNumber}</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">From</span>
              <span className="font-mono text-sm break-all">{transaction.from}</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">To</span>
              <span className="font-mono text-sm break-all">{transaction.to}</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Value</span>
              <span>{transaction.amount} ETH</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Gas Price</span>
              <span>{transaction.gasPrice} Gwei</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Gas Limit</span>
              <span>{transaction.gas}</span>
            </div>
            
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Timestamp</span>
              <span>{new Date(transaction.timestamp).toLocaleString()}</span>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 px-4 py-4 sm:px-6 flex justify-end">
          <Link href="/dashboard">
            <span className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 cursor-pointer">
              Back to Dashboard
            </span>
          </Link>
        </div>
      </div>
    </div>
  );
}