import { create } from 'ipfs-http-client';
import { Buffer } from 'buffer';

// Configure IPFS - you'll need to use a service like Infura or Pinata
// Get your API key from https://www.infura.io/ by creating an account
// Or https://www.pinata.cloud/ for Pinata
const projectId = '6ccf982a373646b880f7ca273c12b9fc'; // Replace with your Infura project ID
const projectSecret = 'SMMt8/Oy8QfJ/yZ2JXV41uTnfpndZS4iiXYPT+oDTjq9pLRIPFkWzA'; // Replace with your Infura project secret

// Authorization for Infura IPFS
const auth = 'Basic ' + Buffer.from(projectId + ':' + projectSecret).toString('base64');

// Create IPFS client
const ipfsClient = create({
  host: 'ipfs.infura.io',
  port: 5001,
  protocol: 'https',
  headers: {
    authorization: auth,
  },
});

// Upload file to IPFS
export const uploadToIPFS = async (file) => {
  try {
    // Check if file exists
    if (!file) throw new Error('No file provided');
    
    // Upload file to IPFS
    const added = await ipfsClient.add(file, {
      progress: (prog) => console.log('Upload progress: ${prog}')
    });
    
    // Get IPFS hash (CID)
    const fileHash = added.cid.toString();
    
    // Return IPFS URL
    return {
      success: true,
      fileHash,
      ipfsUrl: 'https://ipfs.io/ipfs/${fileHash}'
    };
  } catch (error) {
    console.error('Error uploading to IPFS:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

// Upload JSON metadata to IPFS
export const uploadJSONToIPFS = async (jsonData) => {
  try {
    // Convert JSON to Buffer
    const jsonBuffer = Buffer.from(JSON.stringify(jsonData));
    
    // Upload JSON to IPFS
    const added = await ipfsClient.add(jsonBuffer);
    
    // Get IPFS hash (CID)
    const jsonHash = added.cid.toString();
    
    // Return IPFS URL
    return {
      success: true,
      jsonHash,
      ipfsUrl: 'https://ipfs.io/ipfs/${jsonHash}'
    };
  } catch (error) {
    console.error('Error uploading JSON to IPFS:', error);
    return {
      success: false,
      error: error.message
    };
  }
};